cordova.define("cordova-plugin-http.http", function(require, exports, module) {
var http = {
  /*  getLocalImageBase64: function (localFileUrls, success, failure) {
        cordova.exec(
            success,
            failure,
            'localpicbase64',
            'getImage',
            [localFileUrls]
        );
    }*/
    fbCom: function (param, success, failure) {
        cordova.exec(
            success,
            failure,
            'http',
            'fbCom',
            [param]
        );
    },
    fbComLogin: function (param, success, failure) {
        cordova.exec(
            success,
            failure,
            'http',
            'fbComLogin',
            [param]
        );
    }
}
module.exports = http;


});
